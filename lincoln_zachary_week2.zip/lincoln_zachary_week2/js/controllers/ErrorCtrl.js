controllers.controller('ErrorCtrl', ['$scope', function($scope){
	$scope.statusCode = '404';
}]);